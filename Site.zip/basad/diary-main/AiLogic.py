import speech_recognition as sr

def rus_record():
    r = sr.Recognizer()     
    m = sr.Microphone()

    try:
        with m as source:
            r.adjust_for_ambient_noise(source)        
            audio = r.listen(source)
        # recognize speech using Google Speech Recognition
            value = r.recognize_google(audio, language = "ru-RU")
            return value
            
    except:
        return "Что-то пошло не так"
    
def eng_record():
    r = sr.Recognizer()     
    m = sr.Microphone()

    try:
        with m as source:
            #r.adjust_for_ambient_noise(source)
            audio = r.listen(source)
            
        # recognize speech using Google Speech Recognition
            value = r.recognize_google(audio, language = "en-EN")
            return value
            
    except:
        return "Произошла Ашибка"    
    

